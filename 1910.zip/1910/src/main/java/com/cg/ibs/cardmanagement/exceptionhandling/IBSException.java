package com.cg.ibs.cardmanagement.exceptionhandling;

public class IBSException  extends Exception{

	
	public IBSException(String s) 
    { 
        // Call constructor of parent Exception 
        super(s); 
    } 
}
